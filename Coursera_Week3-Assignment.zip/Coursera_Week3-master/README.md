# Coursera_Week3
Week Three Assignment for Coursera Course: HTML, CSS, and Javascript for Web Developers 
